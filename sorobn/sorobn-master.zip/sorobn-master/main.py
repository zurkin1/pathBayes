def main():
    print("Hello from sorobn!")


if __name__ == "__main__":
    main()
